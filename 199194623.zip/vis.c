#include <unistd.h> //Para utilizar fork(), pipes(), entre otros
#include <stdio.h> //Funciones de entrada y salida como printf
#include <stdlib.h> //Asignación de memoria, atoi, etc.
#include <string.h> 
#include <sys/wait.h> //Define las constantes simbólicas para usar con waitpid(), wait() por ejemplo
#include <sys/types.h>
#include "funciones.c"

#define POSICION_U 0
#define POSICION_V 1
#define VALOR_REAL 2
#define VALOR_IM 3
#define RUIDO 4

#define MEDIA_REAL 0
#define MEDIA_IM 1
#define POTENCIA_TOTAL 2
#define RUIDO_TOTAL 3

//Laboratorio 1 Sistemas Operativos
//Nombres: Gerardo Lucero Córdova
//Rut: 19.919.462-3
//Sección: B2



int main(int argc, char* argv[]){


	
	int i = 0;
	//variable para guardar la cadena recibida por el proceso padre
	char buffer[300];

	//Variable para guardar el nombre del archivo de salida
	char* nombreArchivoSalida = argv[2];

	//Variable para guardar el valor de la bandera -b
	int valor_flagB = atoi(argv[3]);


	int cantidadVisibilidades = 0;

	//variable para guardar el numero del proceso hijo en donde me encuentro.
	//Esto en caso de que aquel dato sea requerido.
	int numeroProcesoHijo = atoi(argv[1]);

	//Variable para guardar el arreglo de flotantes con los datos de la visibilidad recibida en forma de cadena de caracteres por parte del proceso padre
	float* datosVisibilidad;

	//Variables para guardar los datos obtenidos de las visibilidades
	float mediaReal;
	float mediaImaginaria;
	float potenciaDisco;
	float ruidoTotal;

	//array para guardar los datos de las visibilidades procesadas
	float* propiedadesDisco = (float*)malloc(sizeof(float)*4);


	//Con tal de no utilizar una matriz, se guardará en su propio array, los datos de las visibilidades recibidas.
	//como por ejemplo la posicion en el eje u, el valor real, etc.
	float* datosPosicionU = (float*)malloc(sizeof(float));
	float* datosPosicionV = (float*)malloc(sizeof(float));
	float* datosValorReal = (float*)malloc(sizeof(float));
	float* datosValorImaginario = (float*)malloc(sizeof(float));
	float* datosRuido = (float*)malloc(sizeof(float));




	while(1){

		//Se lee lo enviado por el proceso padre
		read(STDIN_FILENO, buffer, sizeof(buffer));


		//Si lo enviado es "FIN"
		if(strcmp(buffer,"FIN") == 0){

			//Si la bandera b está levantada
			if(valor_flagB == 1){
				//Se muestra el valor del pid y las visibilidades a procesar por pantalla
				printf("Soy el hijo de pid %d, procesé %d visibilidades\n",getpid(),cantidadVisibilidades);
			}

			//Se realiza el calculo de las propiedades del disco correspondiente
			mediaReal = calcularPromedio(datosValorReal,cantidadVisibilidades);
			mediaImaginaria = calcularPromedio(datosValorImaginario,cantidadVisibilidades);
			potenciaDisco = calcularPotencia(datosValorReal,datosValorImaginario,cantidadVisibilidades);
			ruidoTotal = sumatoria(datosRuido,cantidadVisibilidades);

			//Se guardan las propiedades en un array de flotantes
    		propiedadesDisco[MEDIA_REAL] = mediaReal;
    		propiedadesDisco[MEDIA_IM] = mediaImaginaria;
    		propiedadesDisco[POTENCIA_TOTAL] = potenciaDisco;
    		propiedadesDisco[RUIDO_TOTAL] = ruidoTotal;

  
			//Se escriben las propiedades calculadas en el archivo de salida

			//Se abre el archivo
			FILE* archivoSalida = fopen(nombreArchivoSalida, "a");

			//Se escribe en el archivo la información del disco
			fprintf(archivoSalida,"Disco %d:\nMedia Real: %f\nMedia Imaginaria: %f\nPotencia: %f\nRuido Total: %f\n",numeroProcesoHijo,propiedadesDisco[MEDIA_REAL],propiedadesDisco[MEDIA_IM],propiedadesDisco[POTENCIA_TOTAL],propiedadesDisco[RUIDO_TOTAL]);
			fclose(archivoSalida);

			











    		//se libera la memoria utilizada
			free(datosVisibilidad);
			free(datosPosicionU);
			free(datosPosicionV);
			free(datosValorReal);
			free(datosValorImaginario);
			free(datosRuido);
			free(propiedadesDisco);

			//Se sale del proceso
			return(0);
			break;
		}

		else{

			if(strlen(buffer) > 0){

				//Se aumenta el contador de la cantidad de visibilidades a procesar
				cantidadVisibilidades = cantidadVisibilidades+1;

				//Se obtienen los datos de la cadena recibida
				datosVisibilidad = cadenaAFlotantes(buffer);

				//se agregan los datos recibidos a los arrays que contienen los datos correspondientes acumulados
				//Pero primero, estos arrays deben agrandar su tamaño, para esto se utiliza la funcion realloc
				datosPosicionU = (float*)realloc(datosPosicionU, sizeof(float)*cantidadVisibilidades);
				datosPosicionV = (float*)realloc(datosPosicionV, sizeof(float)*cantidadVisibilidades);
				datosValorReal = (float*)realloc(datosValorReal, sizeof(float)*cantidadVisibilidades);
				datosValorImaginario = (float*)realloc(datosValorImaginario, sizeof(float)*cantidadVisibilidades);
				datosRuido = (float*)realloc(datosRuido, sizeof(float)*cantidadVisibilidades);

				//Se agregan los datos
				datosPosicionU[cantidadVisibilidades-1] = datosVisibilidad[POSICION_U];
				datosPosicionV[cantidadVisibilidades-1] = datosVisibilidad[POSICION_V];
				datosValorReal[cantidadVisibilidades-1] = datosVisibilidad[VALOR_REAL];
				datosValorImaginario[cantidadVisibilidades-1] = datosVisibilidad[VALOR_IM];
				datosRuido[cantidadVisibilidades-1] = datosVisibilidad[RUIDO];

			}//fin if buffer > 0

		}//Fin else
		
	}//fin while
	

	return(0);


}//fin main	