Consideraciones del trabajo realizado:


1.- EL calculo de las propiedades no es 100% exacto debido a un problema a la hora de transformar los datos leídos desde el archivo de entrada, esto se puede ver en las ligeras diferencias que hay respecto a los resultados de ejemplo.


2.- El programa procesa los datos del archivo de entrada y lo recibido por teclado a la hora de ejecutarse, y el proceso padre le envia los datos a sus procesos hijos correspondientes y estos realizan los calculos de las propiedades del disco que le toca evaluar.
Sin embargo, no se logró que los procesos hijos envíen estos resultados al proceso padre.
Pero de todas formas se decidió que los resultados se escribieran en el archivo de salida para que fueran mostrados.


3.- Mas alla de las pequeñas variaciones de los resultados respecto a los archivos de salida de ejemplos, por alguna razon los datos de uno de los discos es erroneo. Esto tampoco pudo ser solucionado.


4.- No se pudo realizar el makefile, por lo que para compilar los archivos lab1.c y vis.c y ejecutar el proceso padre se escribe lo siguiente.


COMPILACION
gcc vis.c -lm -o vis
gcc lab1.c -lm  -o lab1

EJECUCION(ejemplo)
./lab1 -i test10000.csv -o salida1.txt -d 100 -n 4 -b



Es importante que la compilacion de los archivos .c lleven el "-lm" ya que en estos programas se utilizan funciones de la librería math.h y el compilador solo la reconoce colocando ese "-lm" a la hora de compilar.

