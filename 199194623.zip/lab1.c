#include <unistd.h> //Para utilizar fork(), pipes(), entre otros
#include <stdio.h> //Funciones de entrada y salida como printf
#include <stdlib.h> //Asignación de memoria, atoi, etc.
#include <string.h> 
#include <sys/wait.h> //Define las constantes simbólicas para usar con waitpid(), wait() por ejemplo
#include <sys/types.h>
#include <stdint.h>
#include <math.h>
#include <getopt.h>
#include <stdbool.h>
#include "funciones.c"

#define LECTURA 0
#define ESCRITURA 1
#define RANGO_INF 0
#define RANGO_SUP 1
#define INFINITO 9999999
#define DECIMAL 0.0001
#define LIMITE_CADENA 300
#define CANTIDAD_PARAMETROS 5 

//Laboratorio 1 Sistemas Operativos
//Nombres: Gerardo Lucero Córdova
//Rut: 19.919.462-3
//Sección: B2



int main(int argc, char* argv[]){

//banderas para verificar el formato de entrada de los parametros
	int flagI = 0;
	int flagO = 0;
	int flagD = 0;
	int flagN = 0;
    int flagB = 0; //booleano que indica si se activa la bandera -b

//Variables para almacenar lo recibido por teclado
	char* nombreArchivoEntrada;
	char* nombreArchivoSalida;
	char* numeroDiscos;
	char* ancho;

	int c;

	

    //ciclo para obtener los parametros ingresados por teclado
	while((c = getopt(argc, argv, "i:o:d:n:b")) != -1){
		switch(c){
        	case 'i':
                nombreArchivoEntrada = optarg;
                //se levanta la bandera de i
                flagI = 1;
                break;
            case 'o':
                nombreArchivoSalida = optarg;
                //se levanta la bandera de o
                flagO = 1;
                break;
            case 'd':
                ancho = optarg;
                //se levanta la bandera de d
                flagD = 1;
                 break;
            case 'n':
                numeroDiscos = optarg;
                //se levanta la bandera de n
                flagN = 1;
                break;
            case 'b':
                flagB = 1;
                break;
            default:
                printf("Opcion Incorrecta\n");
                return 1;
        }//fin switch
    }//fin while

    //En caso de que alguna bandera no esté levantada quiere decir que el formato de entrada es incorrecto, por lo que se indica por pantalla y se termina el programa
    if(!(flagD && flagI && flagN && flagO)){

    	printf("Error en el formato de entrada\nEjemplo:./lab1 -i archivoeEntrada.csv -o ArchivoSalida.txt -d ancho -n cantidadDiscos \n");
    	return(1);


    }//fin if flag d,i,n,o

    
    //se transforman los valos obtenidos del ancho y la cantidad de discos a entero con la funcion atoi
    int anchoDisco = atoi(ancho);
    int cantidadDiscos = atoi(numeroDiscos);

    //si el ancho del disco o la cantidad de discos es menor o igual a cero
    //se indica el error por pantalla y se cierra el programa
    if(anchoDisco <= 0 || cantidadDiscos <=0){
    	printf("Error al indicar el ancho del disco y/o la cantidad del mismo, precure utilizar valores positivos\n");
    	return(1);
    }


    //A continuación, se crearán los pipes correspondientes para hacer la comunicacion del proceso padre con sus procesos hijos.
    //estos pipes se guardarán en un array, osea será una matriz en que cada fila será un pipe.
    //Como se debe crear una comunicación bidireccional, se realizarán 2 pipes por cada proceso hijo
    //en donde en el primer pipe, el padre escribirá y el hijo leerá y en el segundo el hijo escribirá y el padre leerá
    //Por lo tanto, cada 2 posiciones de la matriz de pipes, se guardarán los pipes correspondientes a la comunicación del
    //proceso padre con su respectivo proceso hijo.

    int cantidadPipes = cantidadDiscos*2;
    int matrizPipes[cantidadPipes][2];

    //iterador 
    int i=0;

    //Mientras queden pipes por crear
    while(i < cantidadPipes){


        //se crea el pipe en el que el padre escribe y el hijo lee
        pipe(matrizPipes[i]);

        //se aumenta el iterador
        i = i+1;

        //se crea el pipe en el que el hijo escribe y el padre lee
        pipe(matrizPipes[i]);

        
        //se aumenta el iterador
        i = i+1;
        
    }//fin while i<cantidadPipes






















//se comienzan a crear los procesos hijos
int cantidadProcesosHijos = cantidadDiscos;
int cantidadProcesosCreados = 0;
int pid = 1;

//mientras queden procesos hijos por crear 
while((cantidadProcesosCreados < cantidadProcesosHijos) && (pid > 0)){

    //Se crea el proceso hijo
    pid = fork();
    cantidadProcesosCreados = cantidadProcesosCreados + 1;

    //Proceso padre
    if(pid > 0){

        //se cierra la lectura en el pipe que el padre escribe para el proceso hijo correspondiente
        close(matrizPipes[(cantidadProcesosCreados*2) - 2][LECTURA]);

        //Se cierra la escritura en el pipe que el padre lee lo enviado por el proceso hijo
        close(matrizPipes[(cantidadProcesosCreados*2) - 1][ESCRITURA]);


    }//fin if pid > 0

    //Proceso hijo
    else if(pid == 0){

        //se cierra la escritura en el pipe que el hijo lee lo enviado por el padre
        close(matrizPipes[(cantidadProcesosCreados*2) - 2][ESCRITURA]);

        //Se cierra la lectura en el pipe que el hijo le escribe al proceso padre
        close(matrizPipes[(cantidadProcesosCreados*2) - 1][LECTURA]);
        

    }//fin if pid == 0

    else{
        printf("Error al crear el proceso hijo\n");
        return(0);
    }



}//fin while cantidadProcesosCreados < cantidadProcesosHijos
































//Se declara un archivo tipo file donde se manipulará el archivo de entrada y salida
FILE* archivo;

//Se crea una matriz donde en cada fila iran guardados los valores del rango inferior y superior del disco para enviar
//las visibilidades leídas a su proceso hijo correspondiente.
//cabe aclarar que a todo rango superior se le restara una constante de 0.0001 llamada DECIMAL para no tener problemas con los intervalos
//Por ejemplo, si son 2 discos con un ancho de 200, la matriz tendría los siguientes valores.
//matrizRango = [[0,199.999], [200,399.999], [400, infinito]];
float matrizRango[cantidadDiscos][2];


//En caso de estar en el proceso padre
if(pid > 0){

    /////Se escribe en el archivo de salida la cantidad de discos y el ancho
    archivo = fopen(nombreArchivoSalida, "w");
    fprintf(archivo, "Archivo de entrada: %s\n%d disco(s), ancho %d\n\n",nombreArchivoEntrada,cantidadDiscos,anchoDisco);
    fclose(archivo);
    /////////////////////////////


    //se abre el archivo de entrada en modo lectura para extraer las visibilidades
    archivo = fopen(nombreArchivoEntrada,"r");

    //Se procede a rellenar la matriz de rangos
    i = 0;
    float valorCota = 0.0; //valor para ir rellenando la matriz de rango

    //mientras se rellena la matriz
    while(i < cantidadDiscos){

        

        //Se ponen los valores de las cotas para los intervalos en la matriz de rangos
        matrizRango[i][RANGO_INF] = valorCota;

        //se suma el ancho para ponerlo en el rango o cota superior del intervalo
        //restandole el decimal constante 0.0001

        valorCota = (valorCota + anchoDisco) - DECIMAL;

        //se pone el valor en el rango superior
        matrizRango[i][RANGO_SUP] = valorCota;

        //Se le vuelve a sumar el decimal restado al valor para ponerlo de cota o rango inferior en la siguiente posicion o "intervalo"
        valorCota = valorCota + DECIMAL;

        //En caso de encontrarme en la ultima posición, se cambia el valor del rango superior por INFINITO
        if(i == cantidadDiscos-1){
            matrizRango[i][RANGO_SUP] = INFINITO;
        }

        i = i+1;

    }//finn while
}//fin if proceso padre














































//arreglo de caracteres donde se leerá la linea del archivo de entrada junto con su copia para poder trabajar con ella
char cadenaLeida[LIMITE_CADENA];
char copiaCadenaLeida[LIMITE_CADENA];


//Se procederá a leer las visibilidades del archivo y luego de acuerdo a su distancia respecto del origen
//se verá a que proceso hijo corresponde enviar la visibilidad leída



//Si estoy en el proceso padre
if(pid > 0){

    int procesoElegido;

    //mientras no se llegue al final del documento
    while(feof(archivo) == 0){


        //se lee la linea completa con un limite de 300 y se transforma a cadena de caracteres
        fgets(cadenaLeida,LIMITE_CADENA,archivo);


        //Para manipular la cadena leída, se pretende realizar split con la funcion strtok
        //pero esta funcion modifica el arreglo, por lo que para evitar problemas se hará una copia del arreglo

        //se procede a copiar la cadena leida
        i = 0;

        //mientras queden elementos por copiar
        while(i < LIMITE_CADENA){

            copiaCadenaLeida[i] = cadenaLeida[i];
            i = i+1;

        }//fin while donde se copia la cadena leida

        //Se calcula la distancia respecto del centro de la visibilidad observada 
        float distancia = calcularDistancia(copiaCadenaLeida,LIMITE_CADENA);


        //Una vez calculada la distancia
        //se procede a revisar a que proceso(disco) se debe enviar la visibilidad analizada

        //se revisa el valor de acuerdo a la matriz de rangos

        i=0;

        
        //mientras se recorre la matriz
        while(i < cantidadDiscos){

            //si la distancia es menor o igual que la cota superior
            if(distancia <= matrizRango[i][RANGO_SUP]){

                //se guarda el numero del proceso elegido para mandarle la cadena de caracteres de la visibilidad observada
                procesoElegido = i+1;
                //se detiene el while ya que se encontró la respuesta
                break;
            }//fin if

            i = i+1;
        }//fin while i < cantidadDiscos

        //Se copia el pipe en el que el proceso padre escribe
        dup2(matrizPipes[(procesoElegido * 2) - 2][ESCRITURA], STDOUT_FILENO);

        //Se envia la cadena leída al proceso correspondiente
        write(STDOUT_FILENO, cadenaLeida, sizeof(cadenaLeida));
        sleep(0.2);

    }//fin while feof(archivo) == 0)

    //Se procede a enviar a los procesos hijos el string de "FIN" para indicar que dejen de leer
    i = 1;

    //mientras queden pipes por escribir
    while(i <= cantidadDiscos){

        //Se copia el pipe del procesor correspondiente
        dup2(matrizPipes[(i * 2) - 2][ESCRITURA], STDOUT_FILENO);

        //se le manda el mensaje al proceso hijo
        write(STDOUT_FILENO,"FIN",sizeof("FIN"));

        i = i+1;
    }//fin while




    //Una vez escrito el mensaje de fin a todos los procesos hijos,
    //Se proceden a cerrar los pipes donde el padre escribe y el proceso hijo lee.
    i = 1;

    //mientras queden pipes por borrar donde el proceso padre escribe
    while(i <= cantidadDiscos){

        //se cierra el pipe
        close(matrizPipes[(i*2) - 2][ESCRITURA]);
        i = i+1;
    }//fin while



}//fin if proceso padre








































































/////////////////proceso hijo
if(pid == 0){

    //Se guarda el numero del proceso, o en realidad el numero de disco

    int numeroProceso = cantidadProcesosCreados;
    char numeroProcesoChar[2];
    sprintf(numeroProcesoChar,"%d",numeroProceso);

    //Se guarda el valor de la bandera -b en formato char
    char flagB_Char[2];
    sprintf(flagB_Char,"%d",flagB);

    //Se copia en la entrada estandar el pipe en donde el proceso hijo lee
    dup2(matrizPipes[(numeroProceso * 2) - 2][LECTURA], STDIN_FILENO);


    //se sobreescribe el proceso hijo
    execl("./vis","./vis",numeroProcesoChar,nombreArchivoSalida,flagB_Char,(char*)NULL);

}//fin if proceso hijo



//En caso de estar en el proceso padre
if(pid > 0){

    //se cierra el archivo de entrada
    fclose(archivo);
}




















    //wait(NULL);
	return(0);
}//fin main